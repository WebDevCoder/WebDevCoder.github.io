/*
 * Подключение плагинов и библиотек
 */
//= ../../bower_components/jquery/dist/jquery.js


/*
 * Подключение js файлов
 */
//= partials/app.js